import { Component, Input } from '@angular/core';
import { CdkDropList } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-menu',
  templateUrl: './app.menu.component.html',
})
export class AppMenuComponent {
  @Input() connectedDropList!: CdkDropList;

  availableElements = [
    { type: 'button', label: 'Button' },
    { type: 'checkbox', label: 'Checkbox' },
    { type: 'date', label: 'Date Picker' },
    { type: 'dropdown', label: 'Dropdown' },
    { type: 'image', label: 'Image' },
    { type: 'input', label: 'Input' },
    { type: 'radio-button', label: 'Radio Button' },
    { type: 'text-area', label: 'Text Area' },
  ];
}
